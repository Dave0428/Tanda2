/* ================= TANDA — database =================
   SQLite by default: one file on disk, nothing to install, perfect while you
   build. When you outgrow it, see docs/DATABASE.md — the SQL below is plain
   enough to move to Postgres with small edits.

   This file also runs the migrations. A migration is one .sql file that
   changes the schema. Files already applied are recorded in the "migrations"
   table, so running it twice is harmless — that is what makes shipping a
   database change to a live server safe.
   ==================================================== */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const file = process.env.SQLITE_PATH || path.join(__dirname, 'tanda.db');
const db = new Database(file);

db.pragma('journal_mode = WAL');   // several readers while one writer works
db.pragma('foreign_keys = ON');    // OFF by default in SQLite. Turn it on.

function migrate(){
  db.exec(`CREATE TABLE IF NOT EXISTS migrations (
    name       TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);

  const dir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  const done = new Set(db.prepare('SELECT name FROM migrations').all().map(r => r.name));

  let applied = 0;
  for(const f of files){
    if(done.has(f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    // One transaction per migration: it lands whole or not at all.
    const run = db.transaction(() => {
      db.exec(sql);
      db.prepare('INSERT INTO migrations (name) VALUES (?)').run(f);
    });
    run();
    console.log('migration applied:', f);
    applied++;
  }
  if(!applied) console.log('database is up to date');
  return applied;
}

module.exports = { db, migrate };

// `npm run migrate` runs this file directly.
if(require.main === module){
  require('dotenv').config();
  migrate();
  console.log('database file:', file);
}
